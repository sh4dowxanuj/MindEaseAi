package com.mindeaseai.ui

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore by preferencesDataStore(name = "settings")

object PersistentKeys {
    val ONBOARDING_COMPLETE = booleanPreferencesKey("onboarding_complete")
}

suspend fun setOnboardingComplete(context: Context, complete: Boolean) {
    context.dataStore.edit { prefs ->
        prefs[PersistentKeys.ONBOARDING_COMPLETE] = complete
    }
}

fun onboardingCompleteFlow(context: Context): Flow<Boolean> =
    context.dataStore.data.map { prefs ->
        prefs[PersistentKeys.ONBOARDING_COMPLETE] ?: false
    }
